<?php
function calcularAreaTriangulo($base, $altura) {
    return ($base * $altura) / 2;
}

// Exemplo de uso
$base = 5;
$altura = 10;

echo "A área do triângulo é: " . calcularAreaTriangulo($base, $altura);
?>
