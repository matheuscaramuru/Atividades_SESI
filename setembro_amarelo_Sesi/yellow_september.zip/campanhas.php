<?php include 'header.php'; ?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Campanhas</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <main>
        <h1>Campanhas de 2024</h1>
        <section>
            <h2>Campanhas Mensais</h2>
            <ul>
                <?php
                // Array com campanhas
                $campanhas = [
                    "Janeiro Azul" => "A campanha Janeiro Azul visa promover a conscientização sobre a importância da saúde mental e a prevenção do suicídio.",
                    "Fevereiro Roxo" => "Fevereiro Roxo destaca a importância da prevenção do câncer, com foco em conscientização e exames regulares.",
                    "Março Verde" => "Março Verde é dedicado à conscientização sobre a saúde do fígado e a importância de uma alimentação saudável.",
                    "Abril Azul" => "Abril Azul promove a conscientização sobre o autismo, enfatizando a importância da inclusão e do apoio às pessoas com autismo.",
                    "Maio Amarelo" => "Maio Amarelo visa a conscientização sobre a segurança no trânsito e a redução de acidentes.",
                    "Junho Vermelho" => "Junho Vermelho é uma campanha para incentivar a doação de sangue e a importância de manter os estoques de sangue.",
                    "Julho Verde" => "Julho Verde destaca a prevenção do câncer bucal e a importância das visitas regulares ao dentista.",
                    "Agosto Dourado" => "Agosto Dourado promove a amamentação e a importância do aleitamento materno para a saúde do bebê.",
                    "Setembro Amarelo" => "Setembro Amarelo é a campanha de prevenção ao suicídio, promovendo a conscientização e apoio à saúde mental.",
                    "Outubro Rosa" => "Outubro Rosa visa a conscientização sobre o câncer de mama e a importância do exame de mamografia.",
                    "Novembro Azul" => "Novembro Azul foca na conscientização sobre o câncer de próstata e a importância dos exames preventivos.",
                    "Dezembro Laranja" => "Dezembro Laranja promove a conscientização sobre a prevenção do câncer de pele e a importância da proteção solar."
                ];

                // Loop para exibir campanhas
                foreach ($campanhas as $nome => $descricao) {
                    echo "<li><strong>$nome</strong>: $descricao</li>";
                }
                ?>
            </ul>
        </section>
    </main>
    <?php include 'footer.php'; ?>
</body>
</html>
