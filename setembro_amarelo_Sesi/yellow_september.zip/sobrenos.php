<?php include 'header.php'; ?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sobre Nós</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <main>
        <h1>Sobre Nós</h1>
        <section>
            <h2>Formulário de Contato</h2>
            <form action="formulario.php" method="POST">
                <label for="nome">Nome:</label>
                <input type="text" id="nome" name="nome" required>
                <br>
                <label for="email">E-mail:</label>
                <input type="email" id="email" name="email" required>
                <br>
                <label for="mensagem">Mensagem:</label>
                <textarea id="mensagem" name="mensagem" required></textarea>
                <br>
                <input type="submit" value="Enviar">
            </form>
        </section>
    </main>
    <?php include 'footer.php'; ?>
</body>
</html>
