    <footer>
        <p>&copy; 2024 SENAI JACAREÍ - Todos os direitos reservados.</p>
    </footer>
</body>
</html>
