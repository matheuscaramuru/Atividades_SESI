<?php include 'header.php'; ?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página Inicial</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <main>
        <h1>Bem-vindo ao nosso site!</h1>
        <section>
            <h2>Campanha Setembro Amarelo</h2>
            <p>A campanha Setembro Amarelo tem como objetivo promover a conscientização sobre a prevenção do suicídio e a valorização da vida. Em setembro, diversas atividades são realizadas para sensibilizar a população sobre a importância da saúde mental.</p>
        </section>
    </main>
    <?php include 'footer.php'; ?>
</body>
</html>
