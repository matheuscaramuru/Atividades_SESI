<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = htmlspecialchars($_POST['nome']);
    $email = htmlspecialchars($_POST['email']);
    $mensagem = htmlspecialchars($_POST['mensagem']);
    
    // Aqui você pode adicionar lógica para enviar o e-mail ou salvar as informações em um banco de dados

    echo "Obrigado, $nome! Sua mensagem foi recebida.";
} else {
    echo "Método de requisição inválido.";
}
?>
