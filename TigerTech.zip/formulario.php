<?php

if (isset($_POST['submit']))
{
    include_once ('config.php');

    $nome = $_POST['nome'];
    $setor = $_POST['setor'];
    $responsavel = $_POST['responsavel'];
    $atuação = $_POST['atuação'];    
    $cnpj = $_POST['cnpj'];
    $cidade = $_POST['cidade'];
    $estado = $_POST['estado'];
    $endereço = $_POST['endereço'];
    $senha = $_POST['senha'];

    $result = mysqli_query($conexao, "INSERT INTO usuarios(nome,setor,responsavel,atuação,cnpj,cidade,estado,endereço,senha)
    VALUES ('$nome','$setor','$responsavel','$atuação','$cnpj', '$cidade','$estado','$endereço','$senha')");

    header('Location: login.php');
//Coleta as variáveis presentes no Banco de Dados e estabelece a conexão para início do formulário, enquanto abaixo é apresentado todo o css (design gráfico) da página web.
//Além, é claro, de montar o Front-End da página, que corresponde ao formulário, e mandar ao Banco de Dados.
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página de Cadastro</title>
    <style>
        body{
            background-image: url('TigerTech.png'); 
            background-repeat: no-repeat;
            top: 30%;
            left: 80%; 
            font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
            background-color: #9ebbeb;
        }
        .box{
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%,-50%);
            background-color: white;
            padding: 50px;
            border-radius: 20px;
            width: 40%;
            border: 1px solid black;
        }
        fieldset{
            border: 3px solid white;
            padding: 10px;
        }
        .inputBox{
            position: relative;
        }
        .inputUser{
            background: none ;
            border: none;
            border-bottom: 1px solid black;
            outline: none;
            font-size: 15px;
            letter-spacing: 2px;
        }
        .labelInput{
            position: absolute;
            top: 0px;
            left: 0px;
            pointer-events: none;
            transition: 0.5s;
        }
        .inputUser:focus ~ .labelInput,
        .inputUser:valid ~ .labelInput{
            top: -20px;
            font-size: 12px;
        }
        #cnpj{
            border: 1px solid black;
            border-radius: 15px;
        }
        button{
            background-image: linear-gradient(white, rgb(102, 188, 249));
            width: 100%;
            padding: 10px;
            font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
            font-size: 20px;
            cursor: pointer;
            border-radius: 20px;
        }
        button:hover{
            background-image: linear-gradient(rgb(214, 212, 212),rgb(59, 163, 237));
        }
        
    </style>
</head>
<body>
<a href="home.php">Voltar</a>
    <div class="box">
        <form action="formulario.php" method="POST">
            <fieldset>
                <legend><b>Formulário para Clientes</b></legend>
                <br>
                <div class="inputBox">
                    <input type="text" name="nome" id="nome" class="inputUser" required>
                    <label for="nome" class="labelInput">Nome da Empresa</label>
                </div>
                <br><br>
                <div class="inputBox">
                    <input type="password" name="senha" id="senha" class="inputUser" required>
                    <label for="senha" class="labelInput">Senha de Acesso</label>
                </div>
                <br><br>
                <div class="inputBox">
                    <input type="text" name="setor" id="setor" class="inputUser" required>
                    <label for="nome" class="labelInput">Setor</label>
                </div>
                <br><br>
                <div class="inputBox">
                    <input type="text" name="responsavel" id="responsavel" class="inputUser" required>
                    <label for="nome" class="labelInput">Responsável Pelo Cadastro</label>
                </div>
                <br>
                <p>Áreas de Atuação</p>
                <input type="radio" id="ar" name="atuação" value="ar" required>
                <label for="ar">Ar</label>
                <input type="radio" id="agua" name="atuação" value="agua" required>
                <label for="agua">Água</label>
                <input type="radio" id="terra" name="atuação" value="terra" required>
                <label for="terra">Terra</label>
                <input type="radio" id="residuos" name="atuação" value="residuos" required>
                <label for="residuos">Resíduos Químicos/Orgânicos</label>
                <input type="radio" id="reciclagem" name="atuação" value="reciclagem" required>
                <label for="reciclagem">Reciclagem</label>
                <br><br>

                    <div class="inputBox">
                    <label for="cnpj"><b>CNPJ da Empresa:</b></label>
                    <input type="number" name="cnpj" id="cnpj" class="inputUser" required>
                    </div>
                    <br>

                    <div class="inputBox">
                    <input type="text" name="cidade" id="cidade" class="inputUser" required>
                    <label for="cidade" class="labelInput">Cidade</label>     
                    <br><br>
                    <div class="inputBox">
                    <input type="text" name="estado" id="estado" class="inputUser" required>
                    <label for="estado" class="labelInput">Estado</label>
                    <br><br>
                    <div class="inputBox">
                    <input type="text" name="endereço" id="endereço" class="inputUser" required>
                    <label for="endereço" class="labelInput">Endereço </label>
                    </div>
                    <br><br>
                    <button type="submit" name="submit" >Criar Cadastro</button>
            
            </fieldset>
        </form>
    </div>
</body>
</html>