<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tela de Login</title>
    <style>
        body {
            font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
            background-color: #9ebbeb;
            background-image: url('TigerTech.png'); 
            background-repeat: no-repeat;
            background-size: 15%;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            color: #333;
            position: relative;
        }
        .container {
            display: flex;
            width: 100%;
            max-width: 1200px;
            padding: 20px;
            justify-content: center; /* Centraliza a caixa de login */
        }
        .central {
            background-color: rgba(255, 255, 255, 0.9);
            padding: 40px;
            border-radius: 20px;
            box-shadow: 0 4px 30px rgba(0, 0, 0, 0.2);
            max-width: 400px;
            text-align: center;
            transition: transform 0.3s;
        }
        .central:hover {
            transform: translateY(-5px);
        }
        .sobre-projeto {
            background-color: rgba(255, 255, 255, 0.9);
            padding: 40px;
            border-radius: 20px;
            box-shadow: 0 4px 30px rgba(0, 0, 0, 0.2);
            max-width: 400px;
            text-align: center;
            transition: transform 0.3s;
        }
        .sobre-projeto:hover {
            transform: translateY(-5px);
        }
        h1 {
            margin-bottom: 20px;
            font-size: 2.5em;
            color: #0077cc;
        }
        input {
            padding: 12px;
            border-radius: 10px;
            outline: none;  
            border: 1px solid gray;
            width: 94%;
            margin-bottom: 15px;
            transition: border 0.3s;
        }
        input:focus {
            border-color: #0077cc;
            box-shadow: 0 0 5px rgba(0, 119, 204, 0.5);
        }
        .inputSubmit {
            padding: 12px;
            border-radius: 10px;
            width: 100%;
            background-image: linear-gradient(white, rgb(102, 188, 249));
            cursor: pointer;
            border: 1px solid gray;
            transition: background 0.3s, transform 0.3s;
            font-weight: bold;
            color: #fff;
        }
        .inputSubmit:hover {
            background-image: linear-gradient(rgb(214, 212, 212), rgb(59, 163, 237));
            transform: scale(1.02);
        }
        ul {
            padding: 0;
            margin: 0;
        }
        ul li {
            list-style: none;
            padding: 10px;
            background-image: linear-gradient(white, rgb(59, 163, 237));
            border-radius: 8px;
            border: 1px solid black;
            margin-top: 10px;
            transition: background 0.3s;
        }
        ul li a {
            text-decoration: none;
            color: black;
            font-weight: bold;
        }
        ul li:hover {
            background-image: linear-gradient(rgb(214, 212, 212), rgb(59, 163, 237));
        }
        .sobre-projeto {
            max-width: 400px; /* Ajuste a largura conforme necessário */
            padding: 20px;
            margin-left: 50px; /* Espaço entre as seções */
            text-align: left; /* Alinha o texto à esquerda */
        }
        h3 {
            margin-top: 0;
            font-size: 1.5em;
            color: #0077cc;
        }
        h4 {
            color: #666;
            font-size: 1em;
            line-height: 1.5;
            margin-top: 10px;
        }
        footer {
            position: absolute;
            bottom: 10px;
            left: 50%;
            transform: translateX(-50%);
            font-size: 0.8em;
            color: #666;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="central">
            <h1>Login</h1>
            <form action="testelogin.php" method="POST">
                <input type="text" name="nome" placeholder="Nome" required>
                <input type="password" name="senha" placeholder="Senha" required>
                <input class="inputSubmit" type="submit" name="submit" value="Entrar">
                <nav>
                    <ul>
                        <li><a href="formulario.php">Criar Cadastro</a></li>
                    </ul>
                </nav>
            </form>
        </div>
        <div class="sobre-projeto">
            <h3>Sobre o Projeto</h3>
            <h4>
                Este projeto visa desenvolver uma plataforma de monitoramento de poluição que permita acompanhar
                a qualidade do ar e da água, registrar denúncias sobre emissões irregulares, e fornecer dados
                e análises para a melhoria do ambiente. Através desta plataforma, buscamos engajar a comunidade
                e promover ações sustentáveis. O projeto se trata de um meio para busca de um meio ambiente 
                sustentável, então caso tenha alguma recomendação, contate-nos em:
            </h4>
            <b>tigertechempresarial@gmail.com</b>
        </div>
    </div>
    <footer>
        &copy; 2024 Plataforma de Monitoramento de Poluição. Todos os direitos reservados.
    </footer>
</body>
</html>
