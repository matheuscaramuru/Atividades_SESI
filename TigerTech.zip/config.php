<?php

$dbHost = 'LocalHost';
$dbUsername = 'root';
$dbPassword = '';
$dbName = 'projeto_jacareísustentável';

$conexao = new mysqli($dbHost,$dbUsername,$dbPassword,$dbName);

//CONECTA o Visual Studio Code (php) ao MySQL (banco de dados)

?>