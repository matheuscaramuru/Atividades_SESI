<?php
session_start();
include_once('config.php'); // Conexão com o banco de dados

// Consulta para obter dados da qualidade do ar
$sql = "SELECT data, qualidade_ar FROM qualidade_ar WHERE estado = 'São Paulo'";
$result = $conexao->query($sql);
$data = [];
$qualidade = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $data[] = $row['data'];
        $qualidade[] = $row['qualidade_ar'];
    }
} else {
    echo "Nenhum dado encontrado.";
}

// Convertendo os dados para JSON
$data_json = json_encode($data);
$qualidade_json = json_encode($qualidade);
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gráfico da Qualidade do Ar</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #9ebbeb; /* Cor de fundo */
            font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
        }
        /* Estilo para o logotipo */
        .logo {
            position: fixed; /* Fixa a posição */
            top: 20px; /* Distância do topo */
            left: 20px; /* Distância da esquerda */
            width: 150px; /* Largura do logotipo */
            z-index: 1000; /* Garante que o logotipo fique acima de outros elementos */
        }
        .container {
            margin-top: 50px; /* Espaço acima do contêiner */
            padding: 20px; /* Espaçamento interno */
        }
        .box {
            background-color: white; /* Fundo branco para a box */
            border-radius: 8px; /* Bordas arredondadas */
            box-shadow: 0 3px 20px rgba(0, 0, 0, 0.3); /* Sombra suave */
            padding: 20px; /* Espaçamento interno da box */
            border: 2px solid black; /* Borda da box */
        }
        h2 {
            margin-bottom: 20px; /* Espaço abaixo do título */
        }
        a {
            background-image: linear-gradient(white, rgb(102, 188, 249));
            width: 100%;
            padding: 10px;
            font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
            font-size: 20px;
            cursor: pointer;
            border-radius: 20px;
            text-decoration: none;
            color: black;
        }
        a:hover {
            background-image: linear-gradient(rgb(214, 212, 212), rgb(59, 163, 237));
            color: black;
        }
    </style>
</head>
<body>
    <img src="TigerTech.png" alt="Logotipo da Empresa" class="logo"> <!-- Logotipo no canto esquerdo -->

    <div class="container">
        <div class="box"> <!-- Caixa para o gráfico -->
            <h2>Gráfico da Qualidade do Ar - São Paulo</h2>
            <canvas id="graficoQualidadeAr"></canvas>
            <a href="agradecimento.php">Voltar para a página anterior</a> <!-- Link para voltar -->
        </div>
    </div>

    <script>
        const ctx = document.getElementById('graficoQualidadeAr').getContext('2d');
        const data = <?php echo $qualidade_json; ?>;
        const labels = <?php echo $data_json; ?>;

        const graficoQualidadeAr = new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Qualidade do Ar',
                    data: data,
                    borderColor: 'rgba(75, 192, 192, 1)',
                    borderWidth: 2,
                    fill: false
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Índice de Qualidade do Ar'
                        }
                    },
                    x: {
                        title: {
                            display: true,
                            text: 'Data'
                        }
                    }
                }
            }
        });
    </script>
</body>
</html>
