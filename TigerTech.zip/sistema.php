<?php
session_start();
include_once('config.php');

// Verifica se o usuário está logado
if (!isset($_SESSION['nome']) || !isset($_SESSION['senha'])) {
    unset($_SESSION['nome']);
    unset($_SESSION['senha']);
    header('Location: login.php');
    exit();
}

$logado = $_SESSION['nome'];

// Processa o envio do formulário de denúncias
if (isset($_POST['submit'])) {
    // Captura a denúncia do formulário
    $denuncia = $_POST['denuncia'];

    // Atualiza a denúncia do usuário na tabela de usuários
    $result = mysqli_query($conexao, "UPDATE usuarios SET denuncia='$denuncia' WHERE nome='$logado'");

    // Verifica se a atualização foi bem-sucedida
    if ($result) {
        // Redireciona para a página de agradecimento
        header('Location: agradecimento.php');
        exit();
    } else {
        echo "<div class='alert alert-danger'>Erro ao registrar a denúncia. Tente novamente.</div>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Sistema</title>
    <style>
        body {
            background-color: #9ebbeb; 
            background-image: url('TigerTech.png');
            background-size: 180px; 
            background-repeat: no-repeat;
            background-position: top 90px left;
            text-align: center;
        }
        .navbar {
            background-color: whitesmoke;
        }
        .box {
            position: absolute;
            top: 60%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: white;
            padding: 20px;
            border-radius: 20px;
            width: 50%;
            border: 1px solid black;
        }
        fieldset {
            border: 3px solid white;
            padding: 10px;
        }
        .inputBox {
            position: relative;
        }
        .inputUser {
            background: none;
            border: none;
            border-bottom: 2px solid black;
            outline: none;
            font-size: 15px;
            letter-spacing: 2px;
        }
        .labelInput {
            position: absolute;
            top: 0px;
            left: 0px;
            pointer-events: none;
            transition: 0.5s;
        }
        .inputUser:focus ~ .labelInput,
        .inputUser:valid ~ .labelInput {
            top: -20px;
            font-size: 12px;
        }
        button { background-image: linear-gradient(white, rgb(102, 188, 249));
            width: 100%;
            padding: 10px;
            font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
            font-size: 20px;
            cursor: pointer;
            border-radius: 20px;
        }
        button:hover {
            background-image: linear-gradient(rgb(214, 212, 212), rgb(59, 163, 237));
        }
           
    </style>
</head>
<body>

<nav class="navbar">
    <a class="navbar-brand" href="#">Sistema Jacareí Ambiental</a>
    <div class="d-flex">
        <a href="sair.php" class="btn btn-danger">Sair</a>
    </div>
</nav>

<div class="box">
    <form action="sistema.php" method="POST">
        <fieldset>
            <legend><b>Formulário de Denúncias</b></legend>
            <br>
            <div class="inputBox">
                <input type="text" name="denuncia" id="denuncia" class="inputUser" required>
                <label for="denuncia" class="labelInput">Digite sua denúncia:</label>
            </div>
            <button type="submit" name="submit">Enviar Denúncia</button>
        </fieldset>
    </form>
</div>

<?php
echo "<h1> Bem-vindo, <u>$logado!</u></h1>";
?>

</body>
</html>
