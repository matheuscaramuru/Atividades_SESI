<?php
session_start();

// Verifica se o usuário está logado
if (!isset($_SESSION['nome'])) {
    header('Location: login.php');
    exit();
}
$logado = $_SESSION['nome'];
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Agradecimento</title>
    <style>
        body{
            background-image: url('TigerTech.png'); 
            background-repeat: no-repeat;
            top: 30%;
            left: 80%; 
            font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
            background-color: #9ebbeb;
            background-size: 15%;

        }
        .container{
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%,-50%);
            background-color: white;
            padding: 50px;
            border-radius: 20px;
            width: 40%;
            border: 1px solid black;
        }
        h1 {
            background: none ;
            border: none;
            border-bottom: 1px solid black;
            outline: none;
            font-size: 25px;
            letter-spacing: 2px;
        }
        p {
            font-size: 18px;
        }
        a {
            background-image: linear-gradient(white, rgb(102, 188, 249));
            width: 100%;
            padding: 10px;
            font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
            font-size: 20px;
            cursor: pointer;
            border-radius: 20px;
            text-decoration: none;
            color: black;
        }
        a:hover {
            background-image: linear-gradient(rgb(214, 212, 212), rgb(59, 163, 237));
            color: black;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Obrigado, <?php echo $logado; ?>!</h1>
        <p>Sua denúncia foi registrada com sucesso.</p>
        <a href="sistema.php">Voltar para a página inicial</a>
        <br><br>
        <a href="recomendacoes.php">Veja como melhorar o meio ambiente</a>
        <br><br>
        <a href="graficoar.php">Veja a análise dos gráficos ambientais atuais </a>
    </div>
</body>
</html>
