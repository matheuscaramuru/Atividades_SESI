<?php
session_start();

// Verifica se o usuário está logado
if (!isset($_SESSION['nome'])) {
    header('Location: login.php');
    exit();
}
$logado = $_SESSION['nome'];
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Recomendações Ambientais</title>
    <style>
        body{
            background-image: url('TigerTech.png');
            background-repeat: no-repeat;
            top: 30%;
            left: 80%; 
            font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
            background-color: #9ebbeb;
            background-size: 15%;

        }
        .container{
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%,-50%);
            background-color: white;
            padding: 30px;
            border-radius: 20px;
            width: 40%;
            border: 1px solid black;
        }
        h1 {
            color: #0288d1;
        }
        ul {
            text-align: left;
            font-size: 18px;
        }
        a {
            background-image: linear-gradient(white, rgb(102, 188, 249));
            width: 100%;
            padding: 10px;
            font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
            font-size: 20px;
            cursor: pointer;
            border-radius: 20px;
            text-decoration: none;
            color: black;
        }
        a:hover {
            background-image: linear-gradient(rgb(214, 212, 212), rgb(59, 163, 237));
            color: black;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Recomendações para Melhorar o Meio Ambiente</h1>
        <ul>
            <li><strong>Reduza o uso de plásticos:</strong> Evite o uso de sacolas plásticas e prefira materiais reutilizáveis.</li>
            <br>
            <li><strong>Economize energia:</strong> Apague as luzes e desligue aparelhos eletrônicos quando não estiverem em uso.</li>
            <br>
            <li><strong>Use transporte sustentável:</strong> Opte por caminhar, andar de bicicleta ou usar transporte público.</li>
            <br>
            <li><strong>Faça reciclagem:</strong> Separe os resíduos de forma correta e participe de programas de reciclagem.</li>
            <br>
            <li><strong>Plante árvores:</strong> Contribua para a preservação do meio ambiente plantando árvores e preservando áreas verdes.</li>
            <br>
            <li><strong>Consuma menos água:</strong> Reduza o tempo no banho e use a água de forma consciente.</li>
        </ul>
        <a href="agradecimento.php">Voltar para a página anterior</a>
    </div>
</body>
</html>
